var data_mentah = {
  "Arabica": [
    {
      "nama": "Arabica Gayo",
      "foto": "images/produk/product_capuchino.jpg",
      "harga": "15.000",
      "size": "250 Ml",
      "link": "https://shopee.co.id/eaifjlesjfi"
        },
    {
      "nama": "Arabica Papua",
      "foto": "images/produk/product_espresso.jpg",
      "harga": "15.000",
      "size": "250 Ml",
      "link": "https://shopee.co.id/eaifjlesjfi"
        }
    ],
  "Robusta": [
    {
      "nama": "Kopi Susu",
      "foto": "images/produk/product_kopi_susu.jpg",
      "harga": "10.000",
      "size": "250 Ml",
      "link": "https://shopee.co.id/eaifjlesjfi"
        }
    ],
  "Non Kopi": [
    {
      "nama": "Es Teh Manis",
      "foto": "https://fajar.co.id/wp-content/uploads/2023/09/IMG_0741.jpg",
      "harga": "10.000",
      "size": "250 Ml",
      "link": "https://shopee.co.id/eaifjlesjfi"
        }
    ]
}

console.log("data mentah:", data_mentah)